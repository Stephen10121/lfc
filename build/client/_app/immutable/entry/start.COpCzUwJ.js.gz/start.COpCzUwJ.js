import{b as a}from"../chunks/entry.D_1wFTvR.js";export{a as start};
