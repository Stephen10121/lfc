import{b as a}from"../chunks/entry.1i-siE8X.js";export{a as start};
