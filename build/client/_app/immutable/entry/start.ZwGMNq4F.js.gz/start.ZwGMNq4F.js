import{b as a}from"../chunks/entry.DzBvDcEj.js";export{a as start};
